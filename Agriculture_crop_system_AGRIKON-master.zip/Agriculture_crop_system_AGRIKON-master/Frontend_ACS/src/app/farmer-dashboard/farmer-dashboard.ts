/*export class Farmer
{
    id:string = '';
    femail:string = '';
    fpass:string = '';
    fname:string = '';
    //crops:any = [{
    //}];
}*/

export class Crops{
    fid:string = '';
    cropid:number = 0;
    cropname:string ='';
    cropimage:any;
    cropqlty:string = '';
    croplocation:string = '';
    cropcontact:string = '';
    cropqnty:string = '';
    cropprice:string = '';
    cropdesc:string = '';
}