import { Component, OnInit } from '@angular/core';
//declare function nav_custom():any;
@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.css']
})
export class LandingPageComponent implements OnInit {

  constructor() {
}

  ngOnInit(): void {
  }

  
}
