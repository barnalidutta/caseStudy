export class Dealer
{
    dealerid:string = '';
    dealeremail: string = '';
    dealerpass: string = '';
    dealername:string = '';
    dealerphone: string= '';
    dealerlocation: string = '';
    dealerabout: string = '';
    dealerimage: string = '';
    dealerbank: string ='';
    dealerbranch: string ='';
    dealeraccountno: string = '';
    dealerpaytmid: string = '';
}
