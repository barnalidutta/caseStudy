package com.controller.dealerservice.model;

import java.util.List;

public class FarmerList {
	
	private List<Farmer> farmerlist;
	
	public FarmerList()
	{
		super();
	}
	
	public List<Farmer> getFarmerlist()
	{
		return farmerlist;
	}
	
	public void setFarmerlist(List<Farmer> farmerlist)
	{
		this.farmerlist = farmerlist;
	}

	
}
