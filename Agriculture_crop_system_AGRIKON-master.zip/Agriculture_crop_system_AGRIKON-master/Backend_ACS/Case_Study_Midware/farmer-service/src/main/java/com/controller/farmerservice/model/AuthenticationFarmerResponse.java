package com.controller.farmerservice.model;

public class AuthenticationFarmerResponse {
	

	private String response;
	
	public AuthenticationFarmerResponse()
	{
		
	}
	public AuthenticationFarmerResponse(String response)
	{
		this.response = response;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
	

}
