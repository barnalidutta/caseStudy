
import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/service/user.service';
import { Washpack } from 'src/app/model/washpack';
import { CartService } from 'src/app/service/cart.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-washpack',
  templateUrl: './washpack.component.html',
  styleUrls: ['./washpack.component.css']
})
export class WashpackComponent implements OnInit {
  washpacks:Array<Washpack>=[];
  constructor(private userservice: UserService,private cartservice:CartService,private router:Router) { }

  ngOnInit(): void {
    this.getWashpacks();
    
  }

  getWashpacks()
 {
   this.userservice.getwashpack().subscribe((washpack: Washpack[])=>
   {
     console.log();
     this.washpacks=washpack;
     this.washpacks.forEach((a:any)=>{
       Object.assign(a,{quantity:1,total:a.price});
     });
   })
   }
   addtocart(data: any){
     this.cartservice.addtocart(data);

   }
   goto(){
     this.router.navigate(['MyOrder'])
   }
}
