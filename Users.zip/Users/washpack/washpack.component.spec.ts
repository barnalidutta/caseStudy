import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WashpackComponent } from './washpack.component';

describe('WashpackComponent', () => {
  let component: WashpackComponent;
  let fixture: ComponentFixture<WashpackComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WashpackComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WashpackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
