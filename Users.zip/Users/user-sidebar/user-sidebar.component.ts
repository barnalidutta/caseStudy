import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/service/cart.service';

@Component({
  selector: 'app-user-sidebar',
  templateUrl: './user-sidebar.component.html',
  styleUrls: ['./user-sidebar.component.css']
})
export class UserSidebarComponent implements OnInit {
  
  public totalItem: number=0;
  constructor(private service:CartService) { }

  ngOnInit(): void {
    this.service.getwashpacks()
    .subscribe((res: string | any[])=>{
      this.totalItem=res.length;
    })
  }

}
