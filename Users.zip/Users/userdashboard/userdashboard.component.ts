import { Component, OnInit } from '@angular/core';
import { Washpack } from 'src/app/model/washpack';
import { UserService } from 'src/app/service/user.service';
import Swal from 'sweetalert2';
import { Order } from 'src/app/model/order';

@Component({
  selector: 'app-userdashboard',
  templateUrl: './userdashboard.component.html',
  styleUrls: ['./userdashboard.component.css']
})
export class UserdashboardComponent implements OnInit {

  washpacks: Washpack[] = [];
  data: Order=new Order();
  constructor(private userservice:UserService) { }

  ngOnInit(): void {
    this.getWashpacks();
  }

  getWashpacks()
 {
   this.userservice.getwashpack().subscribe((washpack: Washpack[])=>
   {
     console.log();
     this.washpacks=washpack;
   });
   }
   

}
