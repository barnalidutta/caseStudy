import { Component, OnInit } from '@angular/core';
import { Order } from 'src/app/model/order';
import { UserService } from 'src/app/service/user.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-addorder',
  templateUrl: './addorder.component.html',
  styleUrls: ['./addorder.component.css']
})
export class AddorderComponent implements OnInit {
  order: Order=new Order();
  constructor(private userservice:UserService) { }

  ngOnInit(): void {
  }
  addOrder(order:Order){
    this.userservice.addorder(this.order).subscribe((data)=>{
      console.log(data);
      Swal.fire({
        title:"Order Booked",
        icon:"success",
      })
    })
  }

}
