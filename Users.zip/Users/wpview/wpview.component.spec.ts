import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WpviewComponent } from './wpview.component';

describe('WpviewComponent', () => {
  let component: WpviewComponent;
  let fixture: ComponentFixture<WpviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WpviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WpviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
