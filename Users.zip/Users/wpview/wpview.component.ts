import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wpview',
  templateUrl: './wpview.component.html',
  styleUrls: ['./wpview.component.css']
})
export class WpviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
