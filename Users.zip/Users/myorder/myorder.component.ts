import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/service/cart.service';
import { Order } from 'src/app/model/order';
import { JwtClientService } from 'src/app/service/jwt-client.service';
import { Router } from '@angular/router';
import { User } from 'src/app/model/user';

@Component({
  selector: 'app-myorder',
  templateUrl: './myorder.component.html',
  styleUrls: ['./myorder.component.css']
})
export class MyorderComponent implements OnInit {
  
  OrderList:Array<Order>=[];
  currentUser:User=new User();
  public washpack:any=[];
  public grandTotal !:number;
  userName!:string;
  constructor(private cartservice:CartService,private service:JwtClientService,private router:Router) { 
    this.service.currentUser.subscribe((data)=>{
      this.currentUser=data;
      this.userName=this.currentUser?.userName;
    })
  }

  ngOnInit(): void {
    this.cartservice.getwashpacks().subscribe((res: any)=>{
      this.washpack=res;
      this.grandTotal=this.cartservice.getTotalprice();
      this.getMyorder();
    })
    
  }
  // removeitem(data:any){
  //   this.cartservice.removeitem(data);
  // }
  // getMyorder(userName:string){
  //   this.cartservice.getByname(this.userName).subscribe((data)=>{
  //     this.OrderList=data
  //   })
  // }
  private getMyorder()
 {
   this.cartservice.get().subscribe((data)=>{
     this.OrderList=data;
   });
   }
}
