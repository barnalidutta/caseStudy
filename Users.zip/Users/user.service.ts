import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Washpack } from '../model/washpack'; 

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private_url:string=""

  constructor(private http:HttpClient) { }

  getwashpack():Observable<Washpack[]>{
    return this.http.get<Washpack[]>("http://localhost:8086/findallwashpackage",{
    
    });
  }
}
